require('colors');
var http = require("http");
var express = require("express");
var bodyParser = require("body-parser");
var mongodb = require("mongodb");
const path = require('path');

const MongoClient = mongodb.MongoClient
const uri = "mongodb+srv://souzabee:3tj6i8QrZ72jZhPf@posts.znrdpwr.mongodb.net/?retryWrites=true&w=majority&appName=posts"
const client = new MongoClient(uri);

var app = express();
app.use(express.static('./public'))
app.use(bodyParser.urlencoded({extended: false}))
app.use(bodyParser.json())
app.set('view engine', 'ejs')
app.set('views', './views');

client.connect().then(() => {
    const dbo = client.db("posts");
    const usuarios = dbo.collection("usuarios");


    app.get('/', (req, res) => {
        res.sendFile(path.join(__dirname, 'public', 'cadastrar_post.html'));
    });

   
    app.post("/cadastrar", (req, res) => {
        console.log("Recebi o POST:", req.body);
        
        const data = {
            db_titulo: req.body.titulo,
            db_resumo: req.body.resumo,
            db_conteudo: req.body.conteudo
        };

        usuarios.insertOne(data)
            .then(() => {
                res.render('menu', { resposta: "Post criado com sucesso!" });
            })
            .catch((err) => {
                console.error("Erro no insertOne:", err);
                res.render('menu', { resposta: "Erro ao criar o post!" });
            });
    });

    // Rota GET: Visualização dos posts salvos (READ).
    app.get('/blog', async (req, res) => {
        try {
            const posts = await usuarios.find().toArray();
            res.render('blog', { posts });
        } catch (err) {
            res.send("Erro ao buscar posts");
        }
    });

    // Iniciar servidor.
    const server = http.createServer(app);
    server.listen(80, () => {
        console.log('Servidor rodando na porta 80'.rainbow);
    });

}).catch(err => {
    console.error("Erro ao conectar ao MongoDB:", err);
});